export default [
  { date: "00:00:00.000", value: "Video Starts" },
  { date: "00:00:03.260", value: "Locker is shown" },
  { date: "00:00:05.123", value: "Open's locker" },
  { date: "00:00:07.850", value: "Pull's something" },
  { date: "00:00:10.200", value: "Cool dancing" },
  { date: "00:00:13.200", value: "Movement 1" },
  { date: "00:00:13.400", value: "Movement 2" },
  { date: "00:00:13.600", value: "Movement 3" },
  { date: "00:00:13.800", value: "Movement 4" },
  { date: "00:00:14.000", value: "Movement 5" },
  { date: "00:00:17.000", value: "Test last event" }
];
