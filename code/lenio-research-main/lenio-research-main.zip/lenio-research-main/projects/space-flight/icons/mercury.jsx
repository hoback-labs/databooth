import * as React from "react";

export const Mercury = () => {
  return (
    <>
      <circle fill="#69B3B2" cx="6.9" cy="6.9" r="6.9"/><circle fill="none" stroke="#55A09C" strokeWidth=".25"  cx="5.7" cy="4.7" r="1.7"/><circle fill="none" stroke="#55A09C" strokeWidth=".25" cx="5.5" cy="9.6" r=".8"/><circle fill="none" stroke="#55A09C" strokeWidth=".25" cx="3.4" cy="2.6" r=".8"/><circle fill="none" stroke="#55A09C" strokeWidth=".25"  cx="8.5" cy="6.5" r="1"/><circle fill="none" stroke="#55A09C" strokeWidth=".25" cx="10.7" cy="3.3" r="1"/><circle fill="none" stroke="#55A09C" strokeWidth=".25"  cx="8.3" cy="11.6" r="1.3"/><circle fill="none" stroke="#55A09C" strokeWidth=".25"  cx="2.7" cy="9.3" r="1.2"/><circle fill="none" stroke="#55A09C" strokeWidth=".25"  cx="11.9" cy="7.5" r="1.3"/><circle fill="none" stroke="#55A09C" strokeWidth=".25"  cx="6.5" cy="1.7" r=".6"/><circle fill="none" stroke="#55A09C" strokeWidth=".25"  cx="8.9" cy="4.2" r=".5"/><circle fill="none" stroke="#55A09C" strokeWidth=".25"  cx="5.5" cy="11.8" r=".5"/><circle fill="none" stroke="#55A09C" strokeWidth=".25"  cx="10.7" cy="10.3" r=".8"/><circle fill="none" stroke="#55A09C" strokeWidth=".25"  cx="7.9" cy="8.8" r=".5"/><circle fill="none" stroke="#55A09C" strokeWidth=".25"  cx="2.3" cy="5.7" r=".7"/>
    </>
  );
};
