import * as React from "react";

export const Sun = () => {
  return (
    <>
      <circle fill="#FFCA30" cx={0} cy={0} r="10" />
    </>
  );
};
