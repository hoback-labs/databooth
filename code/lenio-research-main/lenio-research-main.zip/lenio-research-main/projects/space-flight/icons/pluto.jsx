import * as React from "react";

export const Pluto = () => {
  return (
    <>
        <circle fill="#110628" cx="5" cy="5" r="5"/>
    </>
  );
};
