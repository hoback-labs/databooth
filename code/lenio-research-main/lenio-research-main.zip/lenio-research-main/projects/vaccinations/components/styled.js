import styled from "styled-components";

export const SVGText = styled.text`
  fill: #5a60ab;
  font-size: 1.6rem;
`;
