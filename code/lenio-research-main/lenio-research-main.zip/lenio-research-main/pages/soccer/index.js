import Soccer from "@projects/soccer";

// Test VideoPlayer page
export const Index = () => {
  return (
    <div>
      <Soccer />
    </div>
  );
};

export default Index;
