import styled from "styled-components";

export const Container = styled.div`
  width: 200px;
  height: 120px;
  border: 1px solid white;
`;
export const ImageContainer = styled.div`
  width: 200px;
  height: 100px;
`;
export const Image = styled.img`
  width: 200px;
  height: 100px;
`;
export const Title = styled.div``;
