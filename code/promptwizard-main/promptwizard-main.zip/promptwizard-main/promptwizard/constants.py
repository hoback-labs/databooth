from types import SimpleNamespace

constants = SimpleNamespace(
    OPENAI_API_BASE="OPENAI_API_BASE",
    OPENAI_API_KEY="OPENAI_API_KEY",
    OPENAI_API_TYPE="OPENAI_API_TYPE",
    OPENAI_API_VERSION="OPENAI_API_VERSION"
)