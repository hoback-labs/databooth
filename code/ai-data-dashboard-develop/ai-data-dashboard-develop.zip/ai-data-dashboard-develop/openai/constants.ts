export const GPT_MODEL = {
  TEXT_DAVINCI_003: "text-davinci-003",
  GPT_35_TURBO: "gpt-3.5-turbo"
};
