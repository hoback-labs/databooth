export const palette = ["#6C39DE", "#CF86FC", "#E75B75", "#3EC8BB", "#FFA350"];
