import React from "react";
import styles from "../../styles/Components.module.scss";

export function OpenAIErrorMessage(props: React.PropsWithChildren<{}>) {
  return <div className={styles.dashboardContainer}></div>;
}
